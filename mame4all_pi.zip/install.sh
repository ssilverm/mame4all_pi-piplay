#/bin/sh
#Only used for Pi Store app

cd /usr/local/bin/indiecity/InstalledApps/mame4all_pi/Full
chmod 777 ./mame.cfg ./samples ./artwork ./cfg ./inp ./snap ./hi ./roms ./nvram ./skins ./memcard ./frontend ./folders
